TinhSuper OBF API - minimal example

See README in archive for endpoints.